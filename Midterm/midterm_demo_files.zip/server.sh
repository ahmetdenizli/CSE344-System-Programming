#!/bin/bash

./serverY -s ../../../serverFifo -o logFile -p 2 -r 2 -t 1


